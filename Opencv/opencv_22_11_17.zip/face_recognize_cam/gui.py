#!/usr/bin/python
from Tkinter import *
import numpy as np
import mysql.connector
from PIL import Image
import cv2
import os
root = Tk()
root.geometry("500x500")
var =1
def face_detect(imag):
	face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
	eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')
	img = cv2.imread(imag)
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
 	faces = face_cascade.detectMultiScale(gray, 1.1, 5)
	for(x,y,w,h) in faces:
		img = cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
		roi_gray = gray[y:y+h, x:x+w]
		roi_color = img[y:y+h, x:x+w]
		eyes = eye_cascade.detectMultiScale(roi_gray)
		for (ex,ey,ew,eh) in eyes:
			cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)
	cv2.imwrite('filename.jpeg',img)
	cv2.imshow('img',img)
	cv2.waitKey(0)
	cv2.destroyAllWindows()
	
def database():
	db = mysql.connector.connect(user='deepika', password='12345',
                              host='192.168.4.151',
                              database='OpenCV2')   # connect to DB
	sql1='select * from imglist'
	cursor=db.cursor()
	cursor.execute(sql1)
	#for data in cursor.fetchall():
	#	if data[1] == "baby.jpeg":
			print data[1]
			#f = cv2.imwrite('filename.jpeg',data[1])
			#print f
			face_detect(data[1])
		#fh = open('./nimg/{0}'.format(data[1]),'wb')
		#fh.write(data[2])
		#fh.close()
		#img = cv2.imread('./nimg/baby.jpeg'.format(data[1]),cv2.IMREAD_UNCHANGED)
		#cv2.imwrite('filename.jpg',img)
		#face_detect('filename.jpg')
		#cv2.imshow('image',img)
		#cv2.waitKey(0)
	#cv2.destroyAllWindows()
	db.close()	
def local_browse():
	from tkFileDialog import askopenfilename
	Tk().withdraw()
	browse = askopenfilename()
	face_detect(browse)
def cam():
	print "camera call back"
	cam = cv2.VideoCapture(0) 
	s, img = cam.read()
	print s
	file1= cv2.imwrite("filename.jpg",img)
	print file1
	if s:
		face_detect('filename.jpg')
	    
local = Button(root,text="local",command=local_browse)
local.pack()
camera = Button(root,text="camera",command=cam)
camera.pack()
web = Button(root,text="database",command=database)
web.pack()
close = Button(root,text="close",command=root.destroy)
close.pack(side="bottom")
root.mainloop()
