#!/usr/bin/python
from Tkinter import *
import db
import train
import detect
import sys
root = Tk()
root.geometry("500x500")
gCamera=0
gbuttons=0
def enter_db():
	global gCamera
	db.add_details(gCamera)
	train.train_person()
def layer():
	global gbuttons
	if gbuttons == 1:
		return
	b1 = Button(root,text="add",command=enter_db)
	b1.pack()
	b2 = Button(root,text="detect",command=detect_layer)
	b2.pack()
	gbuttons=1
def detect_layer():
	global gCamera
	detect.detect_person(gCamera)
	
def cam_function():
	global gCamera
	gCamera = 1
	layer()
def local_function():
	global gCamera
	gCamera = 0
	layer()
def close():
	root.destroy()
	sys.exit(1)
if __name__ == "__main__":
	global flag
	flag=1
	b = Button(root,text="Cam",command=cam_function)
	b.pack()
	b4 = Button(root,text="local",command=local_function)
	b4.pack()
	b5 = Button(root,text="close",command=close)
	b5.pack(side="bottom")
	root.mainloop()
