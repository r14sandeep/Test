#!/bin/sh
/home/ghanasan/Documents/Smart\ Campus/Team3/source_code_pc_git/final_bt_ble_thread2/make
